#!/bin/bash
# final_mn11.sh - final verification of optimal MN11/MN12 size (w=1.5u, nf=3)
set -e
unset LD_LIBRARY_PATH; unset LD_PRELOAD; export LD_LIBRARY_PATH=
FIN=${FINESIM:-finesim}
Z=$(pwd)
SUB="$Z/final_mn11_best"
mkdir -p "$SUB"

NETLIST="$Z/netlist_doubletail_nmoslatch.sp"
TB="$Z/testbench_004.sp"

cp "$NETLIST" "$SUB/netlist.sp"
cp "$TB" "$SUB/run.sp"

# patch XMN11/XMN12 to optimal: w=1.5e-6 (1.5u), nf=3
sed -i "/^XMN11 /s/w=[0-9e.nu-]*/w=1.5e-6/; /^XMN11 /s/nf=[0-9]*/nf=3/" "$SUB/netlist.sp"
sed -i "/^XMN12 /s/w=[0-9e.nu-]*/w=1.5e-6/; /^XMN12 /s/nf=[0-9]*/nf=3/" "$SUB/netlist.sp"
sed -i "s/\.param wmn11.*/.param wmn11 = 1.5u/" "$SUB/run.sp"
sed -i "s/\.param nf11.*/.param nf11 = 3/" "$SUB/run.sp"
sed -i "s#netlist_doubletail_nmoslatch.sp#$SUB/netlist.sp#" "$SUB/run.sp"

echo "== MN11/MN12 (optimal) =="
grep -nE "^XMN1[12] " "$SUB/netlist.sp" | sed 's/ l=.*//'

( cd "$SUB" && timeout 120 "$FIN" run.sp > run.log 2>&1 ) || true
echo "rc=$? completed:"
grep -c "FineSim Successfully Completed" "$SUB/run.log" 2>/dev/null || echo 0

echo "== measures =="
cat "$SUB/run.mt0.csv" 2>/dev/null | head -5
