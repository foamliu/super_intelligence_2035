#!/bin/bash
# sweep_mn11.sh - sweep MN11/MN12 reset NMOS sizes in doubletail_nmoslatch
# FOM = CK2Q_DFE_T_F * Cur_slicer_latch_avg; constraint: max(V_outn,V_outp)<=600mV
set -e
unset LD_LIBRARY_PATH; unset LD_PRELOAD; export LD_LIBRARY_PATH=
FIN=${FINESIM:-finesim}
Z=$(pwd)
OUT="$Z/sweep_mn11_work"
mkdir -p "$OUT"

NETLIST="$Z/netlist_doubletail_nmoslatch.sp"
TB="$Z/testbench_004.sp"

# (wmn11 nf) size pairs: from small to large, nf ~ 0.4-0.5um/finger
SIZES=(
  "200n 1"
  "400n 1"
  "600n 2"
  "800n 2"
  "1u 2"
  "1.2u 3"
  "1.5u 3"
  "1.6u 3"
  "1.8u 4"
  "2u 4"
)

echo "wmn11,nf,cur_slicer_latch_avg,t_ldfe_first_fall,v_outn_stg1_at,v_outp_stg1_at,ldfe_dm_at,ck2q_dfe_t_f,ck2q_dfe_b_f,temper,alter#" > "$OUT/sweep_mn11.csv"

idx=0
for pair in "${SIZES[@]}"; do
  w=$(echo $pair | awk '{print $1}')
  nf=$(echo $pair | awk '{print $2}')
  idx=$((idx+1))
  SUB="$OUT/pt_${w}_${nf}"
  mkdir -p "$SUB"
  cp "$NETLIST" "$SUB/netlist.sp"
  cp "$TB" "$SUB/run.sp"
  # patch XMN11/XMN12 w= and nf= in netlist
  sed -i "/^XMN11 /s/w=[0-9e.nu-]*/w=${w}/; /^XMN11 /s/nf=[0-9]*/nf=${nf}/" "$SUB/netlist.sp"
  sed -i "/^XMN12 /s/w=[0-9e.nu-]*/w=${w}/; /^XMN12 /s/nf=[0-9]*/nf=${nf}/" "$SUB/netlist.sp"
  # patch .param in testbench
  sed -i "s/\.param wmn11.*/.param wmn11 = ${w}/" "$SUB/run.sp"
  sed -i "s/\.param nf11.*/.param nf11 = ${nf}/" "$SUB/run.sp"
  sed -i "s#netlist_doubletail_nmoslatch.sp#$SUB/netlist.sp#" "$SUB/run.sp"
  # run FineSim
  ( cd "$SUB" && timeout 120 "$FIN" run.sp > run.log 2>&1 ) || true
  # parse .mt0.csv (19-col FineSim format) -> append condensed row
  python3 -c "
import csv,sys
w='$w'; nf=$nf
with open('$SUB/run.mt0.csv') as f:
    r=csv.DictReader(f)
    for row in r:
        print('%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s' % (
            w, nf,
            row.get('cur_slicer_latch_avg',''),
            row.get('t_ldfe_first_fall',''),
            row.get('v_outn_stg1_at',''),
            row.get('v_outp_stg1_at',''),
            row.get('ldfe_dm_at',''),
            row.get('ck2q_dfe_t_f',''),
            row.get('ck2q_dfe_b_f',''),
            row.get('temper',''),
            row.get('alter#','')))
" >> "$OUT/sweep_mn11.csv" 2>/dev/null || true
done

echo "== sweep results =="
cat "$OUT/sweep_mn11.csv"
echo "== archive dir =="
ls "$OUT"
