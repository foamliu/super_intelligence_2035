#!/usr/bin/env python3
"""parse_mt0.py - parse a FineSim .mt0.csv sweep results file and compute FOM.

Usage:
    python3 parse_mt0.py <input_mt0_csv> <output_results_csv>

Input CSV columns:
    wmn11,nf,cur_slicer_latch_avg,t_ldfe_first_fall,
    v_outn_stg1_at,v_outp_stg1_at,ldfe_dm_at,
    ck2q_dfe_t_f,ck2q_dfe_b_f,temper,alter#

Output CSV columns:
    wmn11,nf,t_ldfe_first_fall,max_v,ldfe_dm_at,
    ck2q_dfe_t_f,ck2q_dfe_b_f,cur_slicer_latch_avg,FOM,constraint_ok

A final '# OPTIMAL' line is appended with the best point (min FOM, constraint satisfied).
"""
import csv
import sys


def parse_w(s):
    """Parse a width string like '200n', '1.5u', '1u' into float meters."""
    s = s.strip()
    if s.endswith('n'):
        return float(s[:-1]) * 1e-9
    if s.endswith('u'):
        return float(s[:-1]) * 1e-6
    return float(s)


def main():
    if len(sys.argv) != 3:
        print("Usage: parse_mt0.py <input_mt0_csv> <output_results_csv>", file=sys.stderr)
        sys.exit(1)

    inp, outp = sys.argv[1], sys.argv[2]
    rows = []
    with open(inp, newline='') as f:
        reader = csv.DictReader(f)
        for r in reader:
            wmn11 = r['wmn11'].strip()
            nf = int(r['nf'].strip())
            latch_avg = float(r['cur_slicer_latch_avg'])
            t_ldfe = float(r['t_ldfe_first_fall'])
            v_outn = float(r['v_outn_stg1_at'])
            v_outp = float(r['v_outp_stg1_at'])
            ldfe_dm = float(r['ldfe_dm_at'])
            ck2q_t = float(r['ck2q_dfe_t_f'])
            ck2q_b = float(r['ck2q_dfe_b_f'])
            fom = ck2q_t * latch_avg
            max_v = max(v_outn, v_outp)
            ok = max_v <= 0.600
            rows.append({
                'wmn11': wmn11,
                'nf': nf,
                't_ldfe_first_fall': t_ldfe,
                'max_v': max_v,
                'ldfe_dm_at': ldfe_dm,
                'ck2q_dfe_t_f': ck2q_t,
                'ck2q_dfe_b_f': ck2q_b,
                'cur_slicer_latch_avg': latch_avg,
                'FOM': fom,
                'constraint_ok': ok,
            })

    # find optimal: min FOM among constraint_ok rows
    feasible = [r for r in rows if r['constraint_ok']]
    if not feasible:
        optimal = min(rows, key=lambda r: r['FOM'])
    else:
        optimal = min(feasible, key=lambda r: r['FOM'])

    fieldnames = ['wmn11', 'nf', 't_ldfe_first_fall', 'max_v', 'ldfe_dm_at',
                  'ck2q_dfe_t_f', 'ck2q_dfe_b_f', 'cur_slicer_latch_avg',
                  'FOM', 'constraint_ok']
    with open(outp, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
        f.write('# OPTIMAL,wmn11=%s,nf=%d,FOM=%.6e,max_v=%.4f,constraint_ok=%s\n' % (
            optimal['wmn11'], optimal['nf'], optimal['FOM'],
            optimal['max_v'], optimal['constraint_ok']))


if __name__ == '__main__':
    main()
