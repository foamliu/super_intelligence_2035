# DRAMTOP PrimeTime read_parasitics 反标失败诊断报告

- 设计：DRAMTOP（PIM LPDDR6 双芯验证平台，Logic Die + DRAM Die）
- 工具：PrimeTime U-2022.12-SP5（STA signoff）
- 输入：Cadence Virtuoso ADE SI Verilog Netlister 网表 DRAMTOP.vp；Synopsys StarRC R-2020.09-SP5-4 生成的 SPEF（IEEE 1481-1999，`.cvps`）
- 结论依据：parasitics_command.log / dramtop.spef / dramtop_netlist.v / calibre_lvs.rule / sdf_interconnect.sdf（均为离线文本，未运行 EDA 工具）

## 1. 反标汇总表

来源：parasitics_command.log 中 `read_parasitics` summary 与 `report_annotated`。

| Net Type                     | Total      | RC network | Not Annotated |
|------------------------------|-----------:|-----------:|--------------:|
| Internal nets (pin to pin)   | 1,005,545  | 1,002,982  | 2,563         |
| Boundary/port nets (pin to pin) | 35,464  | 28,367     | 7,097         |
| TOTAL                        | 1,041,009  | 1,031,349  | 9,660 (0.93%) |

未反标 9,660 条，占 1,041,009 总 net 的 **0.93%**。Boundary/port 类未反标率明显更高（7,097 / 35,464 ≈ 20.0%），与本文第 4 节的 hierarchy 名称 mismatch 一致——跨模块端口 net 最容易被 StarRC 的 merge trivial 节点改写名称。

## 2. 未反标分类（PARA-043 / PARA-044 / PARA-124）

来源：parasitics_command.log `report_annotated` 节选（每类 DES024 显示上限 100 条，计数为完整计数）。

| PARA code | 含义                                              | 计数  | 样例 net                                                              |
|-----------|---------------------------------------------------|------:|----------------------------------------------------------------------|
| PARA-043  | Invalid coupling capacitor（耦合电容节点不在该 net）| 3,871 | `I_Array16GTop.I_Array8G_SC1.I_CMAryB_222.ACLevelA[1]`（电容节点 `I34_1_:A2`） |
| PARA-044  | Invalid capacitor（pin 未连接到该 net）            | 4,902 | `I_Array16GTop.I_Array8G_SC1.I_CMAryB_222.ACLevelA[1]`（pin `I34_1_:A2`） |
| PARA-124  | Cannot find net（网表中找不到该 net）              | 887   | `cm1_ro_ACThDefN[3]`（在 design 'DRAMTOP' 中找不到）                   |
| TOTAL     |                                                   | 9,660 |                                                                      |

3,871 + 4,902 + 887 = 9,660。

三类共同指向同一根因（见第 4 节）：SPEF 里是 StarRC merge 后的层级/名称，网表里是 Cadence SI 保留的完整层级/名称，两者对不上。PARA-044（4,902）与大部分 PARA-124（887）主要是 merge-trivial-node 名称 mismatch；PARA-043（3,871）是同一 mismatch 的连带现象——耦合电容的另一端被记在 merge 前的内部节点（如 `net0296[*]`）上，而该节点在 merge 后的 SPEF net 上已不存在，于是被判定为 off-net。

## 3. PrimeTime 反标匹配机制

`read_parasitics -keep_capacitive_coupling -format spef` 对 SPEF 中每条 net/pin 依次：

1. 在 Verilog 网表中搜索同名 net（逐层级全名匹配）；
2. 验证该 pin 确实连接到此 net（pin 与 net 的 connectivity 检查）；
3. 找不到同名 net → 记 `PARA-124`（Cannot find net）；
4. pin 不连接到该 net → 记 `PARA-044`（Invalid capacitor）；
5. 耦合电容至少一个节点不在当前 net 上 → 记 `PARA-043`（Invalid coupling capacitor）；
6. 命中任一错误 → 该 net **不反标**（Not Annotated）。

要点：第 1 步是**全名逐层级精确匹配**。只要 SPEF 的 net 名称（merge 后）与网表的 net 名称（完整层级）有一个中间层级或节点名不一致，就会从第 1 步直接落到 PARA-124；若 merge 后名称恰好存在但 pin 落在被 merge 掉的内部节点上，则进一步在 connectivity 校验中落到 PARA-044/PARA-043。

## 4. 根因分析：跨 EDA 厂家 hierarchy 策略差异

**根因是跨厂家的 hierarchy 提取/命名策略不一致，而不是寄生参数本身损坏。**

- SPEF 由 **Synopsys StarRC**（R-2020.09-SP5-4）生成。StarRC 在 RC 提取时会 **merge 掉不重要的中间 trivial 节点**（如缓冲/反相器链的中间 hop、`net0296[*]` 这类内部节点），并把合并后的 net 命名到最终端口/输出 net（如 `ACDef[3]`、`ACLevelA[1]`、`ACThLevelA[3]`、`ACThDefN[3]`）。
- 网表由 **Cadence Virtuoso ADE SI Verilog Netlister** 生成。Cadence SI **保留完整层级**，把上述中间 hop 作为独立 net 保留下真实名称（如 `net0296[3]`、`net0296[2]`、`net023`、`cm1_ro_ACThLevelA[3]`、`cm1_ro_ACThDefN[3]`）。
- 结果：SPEF 里的 net 名称（merge 后）与网表里的 net 名称（完整层级）对不上 → PARA-124 / PARA-044 / PARA-043 → **net 未反标**。

日志中给出的样例（parasitics_command.log “sample mismatch”节）：

```text
SPEF net *9977688  -> I_Array16GTop.I_Array8G_SC1.I_CMAryB_222.ACDef[3]
                     (StarRC merged internal node -> ACDef[3])
Cadence netlist    -> mx4Lx2 I34_3_ ( .A2(cm1_ro_ACThLevelA[3]),
                                      .A3(cm1_ro_ACThDefN[3]),
                                      .Y(net0296[3]) )
                   -> net0296[3] 是 Cadence SI 保留、但被 StarRC MERGE 掉的内部 trivial 节点
```

`dramtop.spef` 的 4 条 *D_NET 名称映射也证实了这一策略差异：

| SPEF id    | StarRC merge 后名称                                      |
|------------|----------------------------------------------------------|
| *9977688   | `I_Array16GTop.I_Array8G_SC1.I_CMAryB_222.ACDef[3]`      |
| *9977689   | `I_Array16GTop.I_Array8G_SC1.I_CMAryB_222.ACLevelA[1]`   |
| *9977690   | `I_Array16GTop.I_Array8G_SC1.I_CMAryB_222.ACThLevelA[3]` |
| *9977710   | `I_Array16GTop.I_Array8G_SC1.I_CMAryB_222.ACThDefN[3]`   |

而 `dramtop_netlist.v` 里 Cadence 保留的内部节点是 `net0296[3]`、`net0296[2]`、`net023`、`cm1_ro_ACThLevelA[*]`、`cm1_ro_ACThDefN[*]`。两张表的名称一一错开，即"名称对不上"。

因此这是 **StarRC merge trivial 节点 vs Cadence SI 保留完整 hierarchy** 的跨厂家策略差异导致的系统性反标失败，绝大多数（9,660 中的绝大多数）不是物理寄生问题，可以在 CDL 中 ignore 过滤（见 `noncritical_ignore_list.txt`）。

## 5. 关键 vs 非关键拆分

- **非关键（merge-trivial，可 CDL ignore）**：`net0296[3]→ACLevelA[1]`、`net0296[2]→ACDef[3]`、`cm1_ro_ACThLevelA[2]→ACThLevelA[2]`、`cm1_ro_ACThDefN[2]→ACThDefN[2]`，以及 calibre_lvs.rule 中 `LVS PREFER NETS FILTER` 给出的 `I_Array8G_SC1 / I_CMAryB_222` 两级 `net0296↔ACDef` 反向映射。条目见 `noncritical_ignore_list.txt`（格式 `CellName#OldNetName#NewNetName`，OldNetName 为网表 net，NewNetName 为 SPEF merge 后 net）。
- **关键（需真实修复，不能 ignore）**：`dramtop_netlist.v` 中 `I36_4_`（`.Y(net023)`，"drives an output port directly -> critical"）与 `sdf_interconnect.sdf` 中 `(INTERCONNECT I36_4_/Y topport_n23 ... CRITICAL)` 众口一致地标记 `net023 → topport_n23` 为**直接驱动顶层输出端口**的 net；同时网表注释明确 `ACThLevelA[3]` / `ACThDefN[3]` 是顶层 timing-critical 输出，"not annotated 则 STA signoff 无法闭合"。这些 net 属于真实失败路径，**不可**用 CDL ignore 掩盖——其中 `sdf_interconnect.sdf` 里的全零 INTERCONNECT 延时（0.000::0.000）正是反标失败的症状。清单见 `critical_fails.tsv`。

值得强调的发现：calibre_lvs.rule 的 CDL 示例 `.IGNORE_NET I_CMAryB_222#net023#ACLevelA[1]` 只是展示**格式**的示意条目，若照抄会把 `net023`（真实顶层输出 port，关键）误当作 merge-trivial 节点忽略，导致 STA signoff 漏掉一条真实关键路径。本交付把 `net023`/`topport_n23` 归入 `critical_fails.tsv` 而非 ignore 列表。

## 6. 结论与建议

1. 9,660 条未反标的根因是 StarRC（Synopsys）merge trivial 节点与 Cadence SI 保留完整 hierarchy 的名称策略差异，命中 PARA-043/044/124。
2. 大量 merge-trivial 节点引起的失败可直接用 CDL ignore 过滤（`noncritical_ignore_list.txt`）。
3. 关键失败（`critical_fails.tsv`，含 `net023`/`topport_n23` 与顶层 timing-critical 输出锥 `ACThLevelA[3]`/`ACThDefN[3]` 及其输入锥）必须回归 StarRC 重新出 SPEF（对齐名称策略，例如 `DESIGN_FLOW`/name-map 或关闭 trivial 节点 merge），不可用 ignore 掩盖。
4. 跨 EDA 流程建议：统一两家的 hierarchy/命名策略（在 StarRC 侧保留 or 在 Cadence 侧 flatten trivial 节点），或在 CDL/LVS 中显式维护 `CellName#OldNetName#NewNetName` 映射表（`hierarchy_compare.tsv` 给出对照），使 `read_parasitics` 反标能够闭合。